import matplotlib.pyplot as plt
import numpy as np
# 折线图
#
# epoch,acc,loss,val_acc,val_loss
x_axis_data = [64,128,256,521]
y_axis_data1 = [0.9798,0.9801,0.9795,0.9798]
y_axis_data2 = [0.9817,0.982,0.9817,0.9821]
# y_axis_data3 = [82, 83, 82, 76, 84, 92, 81]
for a, b in zip(x_axis_data, y_axis_data1):
    plt.text(a, b, str(b), ha='center', va='bottom', fontsize=8)  # ha='center', va='top'
for a, b1 in zip(x_axis_data, y_axis_data2):
    plt.text(a, b1, str(b1), ha='center', va='bottom', fontsize=8)
# 画图
plt.plot(x_axis_data, y_axis_data1, 'b*--', alpha=0.5, linewidth=1, label='auc')  # '
plt.plot(x_axis_data, y_axis_data2, 'rs--', alpha=0.5, linewidth=1, label='aupr')
# plt.plot(x_axis_data, y_axis_data3, 'go--', alpha=0.5, linewidth=1, label='acc')

plt.legend()  # 显示上面的label
plt.xlabel('feature dimension')
plt.ylabel('evaluation indicators')  # accuracy

# plt.ylim(-1,1)#仅设置y轴坐标范围
plt.show()
import matplotlib.pyplot as plt
import numpy as np

# 评价指标
evaluation_indicators = ['AUC', 'AUPR', 'ACC', 'Precision', 'Recall', 'F1']

# 数据
data = np.array([
    [0.9781, 0.9805, 0.9208, 0.9123, 0.9309, 0.9214],
    [0.9801, 0.9820, 0.9246, 0.9309, 0.9172, 0.9237],
    [0.9787, 0.9802, 0.9277, 0.9302, 0.9248, 0.9273]
])

# 不同参数的标签
params = ['Param 3', 'Param 5', 'Param 7']

# 设置条形图的宽度
bar_width = 0.25
index = np.arange(len(evaluation_indicators))

# 绘制图形
fig, ax = plt.subplots(figsize=(10, 7))

# 绘制不同参数的数据条
bars1 = ax.bar(index - bar_width, data[0], bar_width, label='Param 3', color='lightblue')
bars2 = ax.bar(index, data[1], bar_width, label='Param 5', color='lightgreen')
bars3 = ax.bar(index + bar_width, data[2], bar_width, label='Param 7', color='lightcoral')

# 添加标签和标题
ax.set_xlabel('Evaluation Indicators')
ax.set_ylabel('Scores')
ax.set_title('Performance Evaluation of Different Parameters')
ax.set_xticks(index)
ax.set_xticklabels(evaluation_indicators)
ax.legend()
ax.set_ylim(0.8, 1.0)
# 显示图形
plt.tight_layout()
plt.show()
# import matplotlib.pyplot as plt
# import numpy as np
#
# # 数据
# labels = np.array(['Accuracy', 'Precision', 'Recall', 'F1-Score', 'AUC', 'AUPR'])
# num_vars = len(labels)
#
# # 模型数据
# models = {
#     'GraphETrans': [0.9277, 0.929, 0.9266, 0.9277, 0.98, 0.9817],
#     '-NE': [0.8753, 0.8803, 0.869, 0.8744, 0.9347, 0.9374],
#     '-NL': [0.92, 0.9211, 0.9186, 0.9197, 0.9755, 0.9786],
#     '-NP': [0.9246, 0.9281, 0.9199, 0.9239, 0.9775, 0.9802],
#     '-RG': [0.9277, 0.9343, 0.92, 0.927, 0.9762, 0.979],
#     '-SM': [0.9223, 0.9268, 0.9176, 0.922, 0.9748, 0.9777]
# }
#
#
# # 创建雷达图
# def create_radar_chart(ax, data, labels, color, model_name):
#     # 角度计算
#     angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False).tolist()
#     angles += angles[:1]  # 形成闭合的图形
#
#     # 数据处理
#     data += data[:1]  # 形成闭合的图形
#
#     # 绘制雷达图
#     ax.plot(angles, data, color=color, linewidth=2, label=model_name)
#
#
# fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(polar=True))
#
# # 绘制每个模型的雷达图
# colors = ['b', 'r', 'g', 'y', 'c', 'm']
# for (model_name, data), color in zip(models.items(), colors):
#     create_radar_chart(ax, data, labels, color, model_name)
#
# # 设置雷达图的标签
# angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False).tolist()
# angles += angles[:1]  # 形成闭合的图形
# ax.set_yticks([0.8, 0.9, 1.0])
# ax.set_yticklabels(['0.8', '0.9', '1.0'], color='grey', size=7)
# ax.set_xticks(angles[:-1])
# ax.set_xticklabels(labels, size=10, color='black')
#
# # 添加图例
# ax.legend(loc='upper right', bbox_to_anchor=(1.1, 1.1))
#
# # 设置雷达图的范围
# ax.set_ylim(0.8, 1.0)
#
# # 标题
# plt.title('Model Performance Comparison', size=15, y=1.1)
#
# # 显示图形
# plt.show()





