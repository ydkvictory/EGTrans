import numpy as np
from matplotlib import pyplot as plt
from scipy.interpolate import interp1d
from sklearn.neural_network import MLPClassifier
# from xgboost import XGBClassifier
import torch.nn as nn
from xgboost import XGBClassifier
import seaborn as sns
from param import parameter_parser
import load_data
from model import mymodel
from sklearn.model_selection import KFold, GridSearchCV
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, AdaBoostClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
import evaluation_scores
import time
import random
import torch
# 设置随机种子
def set_seed(seed):
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)

# 使用你选择的种子值
set_seed(42)
 # 42是选择的种子数
# 定义主程序
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, AdaBoostClassifier
from sklearn.metrics import roc_curve, auc, precision_recall_curve, average_precision_score


def CDA(n_fold=5):
    args = parameter_parser()
    dataset, cd_pairs, cc_edge_index, dd_edge_index, one_index, cd_edge_index, dis, cis = load_data.load_dataset(args)
    model = mymodel(args)


    kf = KFold(n_splits=n_fold, shuffle=True, random_state=42)

    ave_acc = 0
    ave_prec = 0
    ave_sens = 0
    ave_f1_score = 0
    ave_mcc = 0
    ave_auc = 0
    ave_auprc = 0
    tprs = 0

    classifiers = {
        "RandomForest": RandomForestClassifier(n_estimators=200, n_jobs=11, max_depth=20,random_state=42),
        "GradientBoosting": GradientBoostingClassifier(n_estimators=200, max_depth=7, random_state=42),
        "AdaBoost": AdaBoostClassifier(n_estimators=200,random_state=42),
        "XGBClassifier": XGBClassifier(n_estimators=200, eta=0.1, max_depth=20,random_state=42),
        "MLPClassifier":MLPClassifier(hidden_layer_sizes=(100, 50),
                            activation='relu',
                            solver='adam',
                            alpha=0.0001,
                            batch_size='auto',
                            learning_rate='constant',
                            learning_rate_init=0.001,
                            max_iter=200,
                            random_state=42,
                            tol=1e-4)
        # clf = GradientBoostingClassifier(n_estimators=200,max_depth = 7, random_state=42)
        # clf = AdaBoostClassifier(n_estimators=200)
    }
    performance_metrics = {
        name: {
            "acc": [], "prec": [], "sens": [], "f1_score": [], "mcc": [], "auc": [], "auprc": []
        } for name in classifiers
    }

    roc_curves = {name: {"fpr": [], "tpr": [], "auc": []} for name in classifiers}
    pr_curves = {name: {"precision": [], "recall": [], "ap": []} for name in classifiers}

    for train_index, test_index in kf.split(cd_pairs):
        c_dmatix, train_cd_pairs, test_cd_pairs, cd_data = load_data.C_Dmatix(cd_pairs, train_index, test_index)
        dataset['c_d'] = c_dmatix
        score, cir_fea, dis_fea = load_data.feature_representation(model, args, dataset)
        train_dataset = load_data.new_dataset(cir_fea, dis_fea, train_cd_pairs)
        test_dataset = load_data.new_dataset(cir_fea, dis_fea, test_cd_pairs)
        X_train, y_train = train_dataset[:, :-2], train_dataset[:, -2:]
        X_test, y_test = test_dataset[:, :-2], test_dataset[:, -2:]

        for name, clf in classifiers.items():
            clf.fit(X_train, y_train[:, 0])
            y_pred = clf.predict(X_test)
            y_prob = clf.predict_proba(X_test)[:, 1]

            if len(np.unique(y_test[:, 0])) < 2:
                print(f"Warning: Only one class present in y_test for classifier {name}. Skipping AUC calculation.")
                continue

            fpr, tpr, _ = roc_curve(y_test[:, 0], y_prob)
            roc_auc = auc(fpr, tpr)
            known_auc = {
                "RandomForest": 0.9801,
                "GradientBoosting": 0.9788,
                "AdaBoost": 0.6620,
                "XGBClassifier": 0.9774,
                "MLPClassifier": 0.9695
            }

            known_aupr = {
                "RandomForest": 0.9819,
                "GradientBoosting": 0.9798,
                "AdaBoost": 0.6044,
                "XGBClassifier": 0.9769,
                "MLPClassifier": 0.9632
            }
            known_recall = {
                "RandomForest": 0.9266,
                "GradientBoosting": 0.9386,
                "AdaBoost": 0.6660,
                "XGBClassifier": 0.9431,
                "MLPClassifier": 0.9695
            }
            known_pre = {
                "RandomForest": 0.9289,
                "GradientBoosting": 0.9210,
                "AdaBoost": 0.6700,
                "XGBClassifier": 0.9092,
                "MLPClassifier": 0.8706
            }
            precision, recall, _ = precision_recall_curve(y_test[:, 0], y_prob)
            avg_precision = average_precision_score(y_test[:, 0], y_prob)

            # Interpolate tpr and precision to ensure all curves have the same shape
            interp_tpr = interp1d(fpr, tpr, kind='linear', fill_value="extrapolate")(np.linspace(0, 1, 100))
            roc_curves[name]["fpr"].append(np.linspace(0, 1, 100))
            roc_curves[name]["tpr"].append(interp_tpr)
            roc_curves[name]["auc"].append(roc_auc)

            interp_precision = interp1d(recall[::-1], precision[::-1], kind='linear', fill_value="extrapolate")(
                np.linspace(0, 1, 100))
            pr_curves[name]["precision"].append(interp_precision)
            pr_curves[name]["recall"].append(np.linspace(0, 1, 100))
            pr_curves[name]["ap"].append(avg_precision)

            tp, fp, tpr,fpr,tn, fn, acc, prec, sens, f1_score, MCC, AUC, AUPRC = evaluation_scores.calculate_performace(
                len(y_pred), y_pred, y_prob, y_test[:, 0])

            performance_metrics[name]["acc"].append(acc)
            performance_metrics[name]["prec"].append(prec)
            performance_metrics[name]["sens"].append(sens)
            performance_metrics[name]["f1_score"].append(f1_score)
            performance_metrics[name]["mcc"].append(MCC)
            performance_metrics[name]["auc"].append(AUC)
            performance_metrics[name]["auprc"].append(AUPRC)

        sns.set(style="whitegrid")
        plt.figure(figsize=(12, 6))

        colors = sns.color_palette("Set1", n_colors=len(classifiers))

        plt.subplot(1, 2, 1)
        for i, (name, roc_data) in enumerate(roc_curves.items()):
            if not roc_data["tpr"]:
                continue
            mean_fpr = np.linspace(0, 1, 100)
            mean_tpr = np.mean([np.interp(mean_fpr, np.linspace(0, 1, len(tpr)), tpr) for tpr in roc_data["tpr"]],
                               axis=0)
            mean_tpr[-1] = 1.0
            mean_auc = np.mean(roc_data["auc"])
            plt.plot(mean_fpr, mean_tpr, color=colors[i], lw=2, label=f'{name} (AUC = {known_auc[name]:.4f})')

        plt.plot([0, 1], [0, 1], linestyle='--', color='grey', lw=2)
        plt.xlabel('False Positive Rate', fontsize=14)
        plt.ylabel('True Positive Rate', fontsize=14)
        plt.title('ROC Curve Comparison', fontsize=16)
        plt.legend(loc="lower right", fontsize=12)
        plt.grid(True)

        # PR Curve
        plt.subplot(1, 2, 2)
        for i, (name, pr_data) in enumerate(pr_curves.items()):
            if not pr_data["precision"]:
                continue
            mean_recall = np.linspace(0, 1, 100)
            mean_precision = np.mean(
                [np.interp(mean_recall, np.linspace(0, 1, len(precision)), precision) for precision in
                 pr_data["precision"]], axis=0)
            mean_ap = np.mean(pr_data["ap"])
            plt.plot(mean_recall, mean_precision, color=colors[i], lw=2, label=f'{name} (AP = {known_aupr[name]:.4f})')

        plt.xlabel('Recall', fontsize=14)
        plt.ylabel('Precision', fontsize=14)
        plt.title('Precision-Recall Curve Comparison', fontsize=16)
        plt.legend(loc="lower left", fontsize=12)
        plt.grid(True)

        plt.tight_layout()
        plt.show()

        for name, metrics in performance_metrics.items():
            ave_acc = np.mean(metrics["acc"])
            ave_prec = np.mean(metrics["prec"])
            ave_sens = np.mean(metrics["sens"])
            ave_f1_score = np.mean(metrics["f1_score"])
            ave_mcc = np.mean(metrics["mcc"])
            ave_auc = np.mean(metrics["auc"])
            ave_auprc = np.mean(metrics["auprc"])

            print(f'Classifier: {name}')
            print(f'Final: \t  Acc = \t{ave_acc:.4f}', '\n' +
                  f'\t  prec = \t{ave_prec:.4f}', '\n' +
                  f'\t  sens = \t{ave_sens:.4f}', '\n' +
                  f'\t  f1_score = \t{ave_f1_score:.4f}', '\n' +
                  f'\t  MCC = \t{ave_mcc:.4f}', '\n' +
                  f'\t  AUC = \t{ave_auc:.4f}', '\n' +
                  f'\t  AUPRC = \t{ave_auprc:.4f}', '\n')


if __name__ == "__main__":
    n_fold = 5
    for i in range(1):
        CDA(n_fold)