import numpy as np
from matplotlib import pyplot as plt


def plot_auc_curves(fprs, tprs, aucs):
    mean_fpr = np.linspace(0, 1, 1000)
    all_tprs = []

    for i in range(len(fprs)):
        # 确保 fprs[i] 和 tprs[i] 是numpy数组
        fprs[i] = np.asarray(fprs[i])
        tprs[i] = np.asarray(tprs[i])

        # 使用 np.interp 插值 tpr 到 mean_fpr
        interp_tpr = np.interp(mean_fpr, fprs[i], tprs[i])
        all_tprs.append(interp_tpr)

        # 设置插值后的 tpr 的第一个值为0.0
        all_tprs[-1][0] = 0.0

        # 绘制每一折的 ROC 曲线
        plt.plot(fprs[i], tprs[i], alpha=0.8, label='ROC fold %d (AUC = %.4f)' % (i + 1, aucs[i]))

    mean_tpr = np.mean(all_tprs, axis=0)
    mean_tpr[-1] = 1.0
    mean_auc = np.mean(aucs)
    auc_std = np.std(aucs)
    plt.plot(mean_fpr, mean_tpr, color='b', alpha=0.8, label='Mean AUC (AUC = %.4f ± %.4f)' % (mean_auc, auc_std))

    plt.plot([-0.05, 1.05], [-0.05, 1.05], linestyle='--', color='navy', alpha=0.4)

    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC curve')
    plt.rcParams.update({'font.size': 10})
    plt.legend(loc='lower right', prop={"size": 8})
    plt.savefig('./auc.jpg', dpi=1200, bbox_inches='tight')
    plt.show()


def plot_prc_curves(precisions, recalls, auprs):
    mean_recall = np.linspace(0, 1, 1000)
    interpolated_precisions = []

    for i in range(len(precisions)):
        # 确保 recalls 和 precisions 是 numpy 数组
        recalls[i] = np.asarray(recalls[i])
        precisions[i] = np.asarray(precisions[i])

        # 使用 np.interp 插值 precision 到 mean_recall
        interp_precision = np.interp(mean_recall, recalls[i], precisions[i])
        interpolated_precisions.append(interp_precision)

        # 设置插值后的 precision 的第一个值为1.0
        interpolated_precisions[-1][0] = 1.0

        # 绘制每一折的 PR 曲线
        plt.plot(recalls[i], precisions[i], alpha=0.8, label='PR fold %d (AUPR = %.4f)' % (i + 1, auprs[i]))

    mean_precision = np.mean(interpolated_precisions, axis=0)
    mean_precision[-1] = 0
    mean_prc = np.mean(auprs)
    prc_std = np.std(auprs)

    # 绘制平均 PR 曲线
    plt.plot(mean_recall, mean_precision, color='b', alpha=0.8,
             label='Mean PR (AUPR = %.4f ± %.4f)' % (mean_prc, prc_std))

    plt.plot([-0.05, 1.05], [1.05, -0.05], linestyle='--', color='navy', alpha=0.4)
    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('PR Curve')
    plt.rcParams.update({'font.size': 10})
    plt.legend(loc='lower left', prop={"size": 8})
    plt.savefig('./pr.jpg', dpi=1200, bbox_inches='tight')
    plt.show()