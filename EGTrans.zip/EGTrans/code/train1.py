
import torch
from sklearn.model_selection import KFold


from torch import nn
import torch.nn.functional as F

import load_data
from param import parameter_parser


def train(model, train_data, optimizer, opt, scheduler,):
    model.train()
    kf = KFold(n_splits=5, shuffle=True)
    args = parameter_parser()

    for epoch in range(0, opt.epoch):
        model.zero_grad()
        dataset, cd_pairs,cc_edge_index,dd_edge_index,one_index,cd_edge_index,dis,cis= load_data.load_dataset(args)
        crna_di_graph= load_data.dgl_heterograph(dis,cis,one_index, args)
        score, x, y = model(train_data,crna_di_graph)
        # loss = SigmoidLoss()
        loss = torch.nn.BCEWithLogitsLoss(reduction='mean')
        # BCEWithLogitsLoss适用于二分类的损失函数 需要二维向量（logits，标签）  结合了Sigmoid和二元交叉熵损失计算 所以可以直接计算损失（不需要经过激活函数的输出）
        loss = loss(score, train_data['c_d'])
        loss.backward()
        optimizer.step()
        if scheduler:
            scheduler.step()
        print(loss.item())
        current_lr = optimizer.param_groups[0]['lr']
        print(f"Epoch {epoch + 1}/{opt.epoch}, Learning Rate: {current_lr:.6f}")
    score = score.detach().cpu().numpy()
    print('epoch:', epoch)
    return model



