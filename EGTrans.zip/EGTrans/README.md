EG-TransAttention: 
A Dual Attention Model Incorporating Edge Weights 
for Predicting circRNA-Disease Associations.


Our model, EG-TransAttention, leverThe contributions of this work are as follows:
- To the best of our knowledge, EG-TransAttention is the first framework that 
 intergrates edge and node information within a transformer module for RNA-disease
 association prediction. It addresses the over-emphasis on global interactions in
 tradition Transformer models and effectively captures the meta-path structures in heterogeneous biological networks.
- By integrating LightMLA and ParNet Attention, EG-TransAttention enables effective
 extraction of global and local features while preserving hierarchical data structures, 
 thereby enhancing the model's capability to capture latent RNA-disease associations across multi-scale biological contexts.
- Extensive experiments using 5-fold cross-validation on the CircR2Disease and CircRNADisease 
  public databases demonstrate that EG - TransAttention achieves an AUROC of 0.9801 and an AUPR of 0.9820, 
  outperforming other state-of-the-art methods. This validates the excellence of EG-TransAttention in RNA-disease association prediction.


- Run the main model: python __main__.py 

